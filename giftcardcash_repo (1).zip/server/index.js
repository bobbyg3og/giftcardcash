import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import dotenv from 'dotenv';
import { sendEmail } from './email.js';
dotenv.config();
const app = express();
app.use(cors());
app.use(bodyParser.json());
app.get('/health', (req, res) => res.json({status:'ok'}));
app.post('/api/seller-verified', async (req, res) => {
  const { sellerEmail, retailer, faceValue, offerAmount } = req.body;
  if (!sellerEmail) return res.status(400).json({ error: 'sellerEmail required' });
  const html = `<h2>Your card is verified & listed</h2><p>Your ${retailer} card ($${faceValue}) was verified. Offer: $${offerAmount}.</p>`;
  await sendEmail(sellerEmail, 'Your gift card is verified', html);
  res.json({ ok: true });
});
app.post('/api/create-order', (req, res) => res.json({ id: 'demo-order-id' }));
app.post('/api/capture-order', async (req, res) => {
  const { orderID, buyerEmail, items } = req.body;
  const html = `<h2>Order Receipt</h2><p>Order ${orderID} received. Items: ${JSON.stringify(items)}</p>`;
  if (buyerEmail) await sendEmail(buyerEmail, 'Your GiftCardCash Receipt', html);
  res.json({ ok: true });
});
const port = process.env.PORT || 4000;
if (process.env.NODE_ENV !== 'test') {
  app.listen(port, ()=> console.log('Server listening on', port));
}
export default app;
