    GiftCardCash - Minimal GitHub-ready repo

This archive contains a minimal client and server to get you started. Replace client/src/App.jsx with the full app files I provided earlier.

Instructions:
- Unzip, run client and server separately
- Configure server/.env with PayPal + Gmail app password
- Push to GitHub and connect to Vercel (client) and Render (server)
